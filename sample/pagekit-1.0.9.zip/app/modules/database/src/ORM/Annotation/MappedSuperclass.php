<?php

namespace Pagekit\Database\ORM\Annotation;

/**
 * @Annotation
 * @Target("CLASS")
 */
final class MappedSuperclass implements Annotation
{
}
