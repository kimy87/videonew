<?php

namespace Pagekit\Auth\Event;

class AuthorizeEvent extends Event
{
}
